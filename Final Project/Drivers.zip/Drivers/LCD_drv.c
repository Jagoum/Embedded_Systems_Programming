/*
 * LCD_drv.c
 *
 *  Created on: Jan 16, 2025
 *      Author: silvere
 */

#include "global.h"
#include "LCD_drv.h"
#include "drivers/timer_drv.h"
#include <libopencm3/stm32/i2c.h>


void lcd_i2c1Setup(void)
{

	rcc_periph_clock_enable(RCC_GPIOB);
	rcc_periph_clock_enable(RCC_I2C1);

	/*Setup SDA and SCL for I2C communication*/
	gpio_mode_setup(GPIOB, GPIO_MODE_AF, GPIO_PUPD_NONE, (LCD_SCL | LCD_SDA));

	/*Setup SDA and SCL pin as alternate function. */
	gpio_set_af(GPIOB, GPIO_AF4, (LCD_SCL | LCD_SDA));


	i2c_enable_analog_filter(I2C1);
	i2c_enable_stretching(I2C1);
	i2c_set_7bit_addr_mode(I2C1);
	i2c_set_speed(I2C1, i2c_speed_sm_100k, 8);
	i2c_peripheral_enable(I2C1);
}

uint8_t backlight_state = 1;

void lcd_write_nibble(uint8_t nibble, uint8_t rs)
{
	uint8_t data = nibble << D4_BIT;
	data |= rs << RS_BIT;
	data |= backlight_state << BL_BIT; /*Include backlight state in data*/
	data |= 1 << EN_BIT;

	i2c_transfer7(I2C1, LCD_I2C_ADDR, &data, 1, NULL, 0);
	/*HAL_I2C_Master_Transmit(i2cDev.hi2c, I2C_ADDR << 1, &data, 1, 100);*/
	sleep_ms(1);
	data &= ~(1 << EN_BIT);

	i2c_transfer7(I2C1, LCD_I2C_ADDR, &data, 1, NULL, 0);
	/*HAL_I2C_Master_Transmit(i2cDev.hi2c, I2C_ADDR << 1, &data, 1, 100);*/
}

void lcd_send_cmd(uint8_t cmd)
{
	uint8_t upper_nibble = cmd >> 4;
	uint8_t lower_nibble = cmd & 0x0F;
	lcd_write_nibble(upper_nibble, 0);
	lcd_write_nibble(lower_nibble, 0);
	if (cmd == 0x01 || cmd == 0x02)
	{
	  sleep_ms(2);
	}
}


void lcd_send_data(uint8_t data)
{
	uint8_t upper_nibble = data >> 4;
	uint8_t lower_nibble = data & 0x0F;
	lcd_write_nibble(upper_nibble, 1);
	lcd_write_nibble(lower_nibble, 1);
}


void lcd_init(void)
{
	sleep_ms(50);
	lcd_write_nibble(0x03, 0);
	sleep_ms(5);
	lcd_write_nibble(0x03, 0);
	sleep_ms(1);
	lcd_write_nibble(0x03, 0);
	sleep_ms(1);
	lcd_write_nibble(0x02, 0);
	lcd_send_cmd(0x28);
	lcd_send_cmd(0x0C);
	lcd_send_cmd(0x06);
	lcd_send_cmd(0x01);
	sleep_ms(2);
}


void lcd_write_string(char *str)
{
	while (*str)
	{
		lcd_send_data(*str++);
	}
}

void lcd_set_cursor(uint8_t row, uint8_t column)
{
    uint8_t address;
    switch (row)
    {
        case 0:
            address = 0x00;
            break;
        case 1:
            address = 0x40;
            break;
        default:
            address = 0x00;
    }
    address += column;
    lcd_send_cmd(0x80 | address);
}

void lcd_clear(void)
{
	lcd_send_cmd(0x01);
	sleep_ms(2);
}

void lcd_backlight(uint8_t state)
{
  if(state)
  {
    backlight_state = 1;
  }
  else
  {
    backlight_state = 0;
  }
}

void lcd_write_text(char *text_row1, char *text_row2)
{
	lcd_clear();
	sleep_ms(2);
	lcd_set_cursor(0, 0);
	sleep_ms(2);
	lcd_write_string(text_row1);
	sleep_ms(2);
	if(text_row2 != NULL)
	{
		lcd_set_cursor(1, 0);
		sleep_ms(2);
		lcd_write_string(text_row2);
	}
}






uint8_t dpFunction;
uint8_t dpControl;
uint8_t dpMode;
uint8_t dpRows;
uint8_t dpBacklight;


/*
static void SendCommand(uint8_t);
static void SendChar(uint8_t);
static void Send(uint8_t, uint8_t);
static void Write4Bits(uint8_t);
static void ExpanderWrite(uint8_t);
static void PulseEnable(uint8_t);
static void DelayInit(void);
static void DelayUS(uint32_t);

uint8_t special1[8] = {
        0b00000,
        0b11001,
        0b11011,
        0b00110,
        0b01100,
        0b11011,
        0b10011,
        0b00000
};

uint8_t special2[8] = {
        0b11000,
        0b11000,
        0b00110,
        0b01001,
        0b01000,
        0b01001,
        0b00110,
        0b00000
};
*/

//void HD44780_Init(uint8_t rows)
//{
//  dpRows = rows;
//
//  dpBacklight = LCD_BACKLIGHT;
//
//  dpFunction = LCD_4BITMODE | LCD_1LINE | LCD_5x8DOTS;
//
//  if (dpRows > 1)
//  {
//    dpFunction |= LCD_2LINE;
//  }
//  else
//  {
//    dpFunction |= LCD_5x10DOTS;
//  }
//
//  /* Wait for initialization */
//  DelayInit();
//  sleep_ms(50);
//
//  ExpanderWrite(dpBacklight);
//  sleep_us(1000);
//
//  /* 4bit Mode */
//  Write4Bits(0x03 << 4);
//  sleep_us(4500);
//
//  Write4Bits(0x03 << 4);
//  sleep_us(4500);
//
//  Write4Bits(0x03 << 4);
//  sleep_us(4500);
//
//  Write4Bits(0x02 << 4);
//  sleep_us(100);
//
//  /* Display Control */
//  SendCommand(LCD_FUNCTIONSET | dpFunction);
//
//  dpControl = LCD_DISPLAYON | LCD_CURSOROFF | LCD_BLINKOFF;
//  HD44780_Display();
//  HD44780_Clear();
//
//  /* Display Mode */
//  dpMode = LCD_ENTRYLEFT | LCD_ENTRYSHIFTDECREMENT;
//  SendCommand(LCD_ENTRYMODESET | dpMode);
//  sleep_us(4500);
//
//  HD44780_CreateSpecialChar(0, special1);
//  HD44780_CreateSpecialChar(1, special2);
//
//  HD44780_Home();
//}
//
//void HD44780_Clear()
//{
//  SendCommand(LCD_CLEARDISPLAY);
//  sleep_us(2000);
//}
//
//void HD44780_Home()
//{
//  SendCommand(LCD_RETURNHOME);
//  sleep_us(2000);
//}
//
//void HD44780_SetCursor(uint8_t col, uint8_t row)
//{
//  int row_offsets[] = { 0x00, 0x40, 0x14, 0x54 };
//  if (row >= dpRows)
//  {
//    row = dpRows-1;
//  }
//  SendCommand(LCD_SETDDRAMADDR | (col + row_offsets[row]));
//}
//
//void HD44780_NoDisplay()
//{
//  dpControl &= ~LCD_DISPLAYON;
//  SendCommand(LCD_DISPLAYCONTROL | dpControl);
//}
//
//void HD44780_Display()
//{
//  dpControl |= LCD_DISPLAYON;
//  SendCommand(LCD_DISPLAYCONTROL | dpControl);
//}
//
//void HD44780_NoCursor()
//{
//  dpControl &= ~LCD_CURSORON;
//  SendCommand(LCD_DISPLAYCONTROL | dpControl);
//}
//
//void HD44780_Cursor()
//{
//  dpControl |= LCD_CURSORON;
//  SendCommand(LCD_DISPLAYCONTROL | dpControl);
//}
//
//void HD44780_NoBlink()
//{
//  dpControl &= ~LCD_BLINKON;
//  SendCommand(LCD_DISPLAYCONTROL | dpControl);
//}
//
//void HD44780_Blink()
//{
//  dpControl |= LCD_BLINKON;
//  SendCommand(LCD_DISPLAYCONTROL | dpControl);
//}
//
//void HD44780_ScrollDisplayLeft(void)
//{
//  SendCommand(LCD_CURSORSHIFT | LCD_DISPLAYMOVE | LCD_MOVELEFT);
//}
//
//void HD44780_ScrollDisplayRight(void)
//{
//  SendCommand(LCD_CURSORSHIFT | LCD_DISPLAYMOVE | LCD_MOVERIGHT);
//}
//
//void HD44780_LeftToRight(void)
//{
//  dpMode |= LCD_ENTRYLEFT;
//  SendCommand(LCD_ENTRYMODESET | dpMode);
//}
//
//void HD44780_RightToLeft(void)
//{
//  dpMode &= ~LCD_ENTRYLEFT;
//  SendCommand(LCD_ENTRYMODESET | dpMode);
//}
//
//void HD44780_AutoScroll(void)
//{
//  dpMode |= LCD_ENTRYSHIFTINCREMENT;
//  SendCommand(LCD_ENTRYMODESET | dpMode);
//}
//
//void HD44780_NoAutoScroll(void)
//{
//  dpMode &= ~LCD_ENTRYSHIFTINCREMENT;
//  SendCommand(LCD_ENTRYMODESET | dpMode);
//}
//
//void HD44780_CreateSpecialChar(uint8_t location, uint8_t charmap[])
//{
//  location &= 0x7;
//  SendCommand(LCD_SETCGRAMADDR | (location << 3));
//  for (int i=0; i<8; i++)
//  {
//    SendChar(charmap[i]);
//  }
//}
//
//void HD44780_PrintSpecialChar(uint8_t index)
//{
//  SendChar(index);
//}
//
//void HD44780_LoadCustomCharacter(uint8_t char_num, uint8_t *rows)
//{
//  HD44780_CreateSpecialChar(char_num, rows);
//}
//
//void HD44780_PrintStr(const char c[])
//{
//  while(*c) SendChar(*c++);
//}
//
//void HD44780_SetBacklight(uint8_t new_val)
//{
//  if(new_val) HD44780_Backlight();
//  else HD44780_NoBacklight();
//}
//
//void HD44780_NoBacklight(void)
//{
//  dpBacklight=LCD_NOBACKLIGHT;
//  ExpanderWrite(0);
//}
//
//void HD44780_Backlight(void)
//{
//  dpBacklight=LCD_BACKLIGHT;
//  ExpanderWrite(0);
//}
//
//static void SendCommand(uint8_t cmd)
//{
//  Send(cmd, 0);
//}
//
//static void SendChar(uint8_t ch)
//{
//  Send(ch, RS);
//}
//
//static void Send(uint8_t value, uint8_t mode)
//{
//  uint8_t highnib = value & 0xF0;
//  uint8_t lownib = (value<<4) & 0xF0;
//  Write4Bits((highnib)|mode);
//  Write4Bits((lownib)|mode);
//}
//
//static void Write4Bits(uint8_t value)
//{
//  ExpanderWrite(value);
//  PulseEnable(value);
//}
//
//static void ExpanderWrite(uint8_t _data)
//{
//  uint8_t data = _data | dpBacklight;
//  HAL_I2C_Master_Transmit(i2cDev.hi2c, DEVICE_ADDR, (uint8_t*)&data, 1, 10);
//}
//
//static void PulseEnable(uint8_t _data)
//{
//  ExpanderWrite(_data | ENABLE);
//  sleep_us(20);
//
//  ExpanderWrite(_data & ~ENABLE);
//  sleep_us(20);
//}
//
//static void DelayInit(void)
//{
//  CoreDebug->DEMCR &= ~CoreDebug_DEMCR_TRCENA_Msk;
//  CoreDebug->DEMCR |=  CoreDebug_DEMCR_TRCENA_Msk;
//
//  DWT->CTRL &= ~DWT_CTRL_CYCCNTENA_Msk; //~0x00000001;
//  DWT->CTRL |=  DWT_CTRL_CYCCNTENA_Msk; //0x00000001;
//
//  DWT->CYCCNT = 0;
//
//  /* 3 NO OPERATION instructions */
//  __ASM volatile ("NOP");
//  __ASM volatile ("NOP");
//  __ASM volatile ("NOP");
//}
//
