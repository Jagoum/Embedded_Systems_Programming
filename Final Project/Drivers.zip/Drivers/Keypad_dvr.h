/*
 * Keypad_dvr.h
 *
 *  Created on: Jan 16, 2025
 *      Author: silvere
 */

#ifndef DRIVERS_KEYPAD_DVR_H_
#define DRIVERS_KEYPAD_DVR_H_

#include "global.h"

#define RAW0                GPIO11 	//PC11
#define RAW1                GPIO10 	//PC10
#define RAW2                GPIO9 	//PC9
#define RAW3                GPIO8 	//PC8

#define COL0                GPIO12 //PC12
#define COL1                GPIO7 //PC7
#define COL2                GPIO6 //PC6
#define COL3                GPIO2 //PC2

#define KEYPAD_PORT			GPIOC	   // GPIO port C

#define COLUMN_SIZE         4U
#define RAW_SIZE            COLUMN_SIZE
#define KEYPAD_SIZE         (COLUMN_SIZE * RAW_SIZE)
#define KEY_DEBOUNCE_TIME   1000U

#define WRONG_ENTRY_ALLOWED	3U

#define PASSWORD			"7777"
#define RESET_KEY			"99"
#define TEMP_REQ_KEY		"88"
#define END_KEY             '#'


extern uint32_t col_arr[COLUMN_SIZE];
extern uint32_t row_arr[RAW_SIZE];
extern char keypad_values[COLUMN_SIZE][RAW_SIZE];
extern char code_value[7];

void init_keypad(void);
char key_read(void);
char get_key_char(char key);
void get_pin_code(char *code);
bool_t compare_pin(char* code, char* input);



#endif /* DRIVERS_KEYPAD_DVR_H_ */
