/*
 * Keypad_dvr.c
 *
 *  Created on: Jan 16, 2025
 *      Author: silvere
 */


#include "Keypad_dvr.h"
#include "drivers/timer_drv.h"

uint32_t col_arr[COLUMN_SIZE] =
{
	COL0,
	COL1,
	COL2,
	COL3
};

uint32_t raw_arr[RAW_SIZE] =
{
	RAW0,
	RAW1,
	RAW2,
	RAW3
};

char keypad_values[RAW_SIZE][COLUMN_SIZE] =
{
	{'1', '2', '3', 'A'},
	{'4', '5', '6', 'B'},
	{'7', '8', '9', 'C'},
	{'*', '0', '#', 'D'}
};


char code_value[7] = {0};


/**
 * @brief Initialize the keypad
 * 		  Set the column pins as input and the row pins as output
 *
 */
void init_keypad(void)
{
	/* Set all Column pin to Input pull down */
	/* Set all Raw pins as output  */


	/* Enable the GPIOA and GPIOC clock*/

	rcc_periph_clock_enable(RCC_GPIOC);
//	gpio_mode_setup(GPIOC, 	GPIO_MODE_INPUT , GPIO_PUPD_PULLDOWN, (GPIO8 | GPIO8));


	/* Set column pin as input */
	for(uint8_t i = 0; i < (uint8_t)COLUMN_SIZE; i++)
	{
		gpio_mode_setup(GPIOC, 	GPIO_MODE_INPUT , GPIO_PUPD_PULLDOWN, col_arr[i]);
	}

	/* Set raw pins as output */
	for(uint8_t i = 0; i < (uint8_t)RAW_SIZE; i++)
	{
		gpio_mode_setup(GPIOC, 	GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, raw_arr[i]);
	}

	/* Reset all raw to 0*/
	for(uint8_t i = 0; i < (uint8_t)RAW_SIZE; i++)
	{
		gpio_clear(KEYPAD_PORT, raw_arr[i]);
	}
}

/**
 * @brief Read a specific key of the keypad
 * @param void
 * @return key
 */
char  key_read(void)
{
	char key = '\r';
	for(uint8_t raw = 0; raw < (uint8_t)RAW_SIZE; raw++)
	{
		/* Set column pin successively to high */
		gpio_set(KEYPAD_PORT, raw_arr[raw]);
		sleep_ms(2);
		/* Read each row for the current column */
		for(uint8_t column = 0; column < (uint8_t)COLUMN_SIZE; column++)
		{
			if(gpio_get(KEYPAD_PORT, col_arr[column]))
			{
				/* Debounce the button*/
				sleep_ms(150);
				if(gpio_get(KEYPAD_PORT, col_arr[column]))
				{
					key = keypad_values[raw][column];
				}
			}
		}

		/* Reset previous row pin */
		gpio_clear(KEYPAD_PORT, raw_arr[raw]);
		sleep_ms(2);
	}
	return (key);
}



/**
 * @brief Get the pin code object
 * @param code pointer to store the pin code
 * @return void
 */
void get_pin_code(char *code)
{
	char key = 0;
	uint8_t  i = 0;

	while (key != '#')
	{
		key = key_read();

		if((key != '\r') && (key != '#'))
		{
			code[i] = key;
			i++;
		}
	}
}

/**
 * This function comares the input pin code with the real password
 * @param: code the real code
 * @param: input the user input value
 * */

bool_t compare_pin(char *code, char *input)
{
	bool_t result = FALSE;
	if((strncasecmp((const char*)code, (const char*)input, strlen(code))) == 0)
	{
		result = TRUE;
	}
	else
	{
		result = FALSE;
	}
	return (result);
}


